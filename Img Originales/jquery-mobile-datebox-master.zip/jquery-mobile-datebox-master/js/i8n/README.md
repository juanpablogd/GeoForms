jQuery-Mobile-DateBox
=====================

ALL FILES ARE NOW AUTO GENERATED.  PLEASE SEE ../../i18n/po FOR THE PO
FILES THAT ARE USED FOR THIS PROCESS. ONLY THE ONE-OFF FILES EXIST HERE
(CURRENTLY JUST UTF16LE ARABIC).

Include as many of these per-page / per-site as you want.  Last loaded will 
be the "default" language.


Naming: 

jquery.mobile.datebox.i18n.[Language Code].[Type Code].js

Type Codes:

utf16le - UTF-16LE (currently only Arabic)
utf8 - UTF-8 Extended Charaters Present (and what a non type-code file is linked to)
asc - Ascii Encoded (HTML Entities, but no UTF-8 support needed)
none - Linked to the UTF-8 Varient

NOTE ON USE:

Use the UTF-8 Version if (any):

 * You are returning any text names into the input (month or day names, etc)
 * You are serving the page as UTF-8
 * If at all possible.

Use the Ascii Version *only* if:

 * None of your possible langagues use any character outside the ASCII standard (i.e. English)
 * You *cannot* serve the pages as UTF-8
 * You *never* return names for dates, only numbers.

